Protótipo criado
https://www.figma.com/make/WxmoJwYTgQm1YDs4ghlidK/Chrome-extension-for-addiction-support?t=CQi6rVrSfmarra77-20&fullscreen=1

Os fórmularios:
Dos parentes dos viciados

https://docs.google.com/forms/d/e/1FAIpQLSdjR344dERv28MVF9oXwm71eZInZAbTZBEmDY3WeSrYxRmYUg/viewform?usp=dialog

E dos viciados

https://docs.google.com/forms/d/e/1FAIpQLScj_vgEZJA_A4N_bMa7jTn3JUmehgNi9_iW6DYKxSdE4Lgmkg/viewform?usp=dialog


[(    “Toma banho Pedim!!!!!!!”   )]
